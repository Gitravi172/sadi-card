'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'

export default function StylishWeddingInvite() {
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [formData, setFormData] = useState({ name: '', attending: 'yes', comments: '' })
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitStatus('loading')
    try {
      const response = await fetch('/api/submit-rsvp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      })
      if (response.ok) {
        setSubmitStatus('success')
        setFormData({ name: '', attending: 'yes', comments: '' })
        setTimeout(() => { setSubmitStatus('idle'); setIsFormOpen(false) }, 2000)
      } else {
        setSubmitStatus('error')
      }
    } catch (error) {
      setSubmitStatus('error')
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-rose-950 to-slate-950 text-white overflow-hidden relative">
      {/* Party Sparkle Background */}
      <div className="fixed inset-0 pointer-events-none animate-party-shimmer opacity-40" />

      {/* Luxury Floating Elements */}
      <div className="fixed inset-0 pointer-events-none opacity-30">
        <div className="absolute top-20 left-10 w-72 h-72 bg-amber-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob" />
        <div className="absolute top-40 right-10 w-72 h-72 bg-rose-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000" />
        <div className="absolute bottom-32 left-1/2 w-96 h-96 bg-yellow-400 rounded-full mix-blend-multiply filter blur-3xl animate-pulse opacity-20" />
      </div>

      {/* Floating Sparkles */}
      <div className="fixed inset-0 pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-sparkle text-amber-300"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `sparkle ${1.5 + Math.random() * 1}s ease-in-out infinite`,
              animationDelay: `${i * 0.3}s`
            }}
          >
            ✨
          </div>
        ))}
      </div>

      {/* HERO - ULTRA PREMIUM */}
      <section className="relative min-h-screen flex items-center justify-center px-4 py-20">
        <div className="relative z-10 max-w-5xl mx-auto text-center">
          {/* Decorative Text */}
          <div className="mb-12 space-y-2">
            <p className="text-amber-400 font-light tracking-widest text-sm uppercase">✨ शुभ विवाह निमंत्रण ✨</p>
            <div className="h-1 w-24 bg-gradient-to-r from-amber-400 to-rose-400 mx-auto" />
          </div>

          {/* Couple Names - ULTRA STYLISH */}
          <div className="mb-8">
            <h1 className="text-6xl md:text-8xl font-serif font-bold mb-2 bg-gradient-to-r from-amber-300 via-amber-200 to-rose-200 bg-clip-text text-transparent drop-shadow-lg">
              अजित
            </h1>
            <p className="text-xl md:text-2xl text-amber-200  font-light tracking-widest mb-6">संग</p>
            <h1 className="text-6xl md:text-8xl font-serif font-bold bg-gradient-to-r from-rose-200 via-amber-200 to-amber-300 bg-clip-text text-transparent drop-shadow-lg">
              करूणा
            </h1>
          </div>

          {/* Subtitle */}
          <p className="text-lg md:text-2xl text-amber-100 font-light mb-8 max-w-2xl mx-auto leading-relaxed">
            “अजित ❤️ करूणा <br></br>

            अपने जीवन के इस स्वर्णिम और पावन मिलन के साक्षी बनने हेतु
            आपको सपरिवार स्नेहपूर्वक आमंत्रित करते हैं।
            आपकी उपस्थिति ही हमारे लिए सबसे बड़ा आशीर्वाद और सम्मान होगी।”
          </p>

          {/* Date & Location */}
          <div className="flex flex-col md:flex-row justify-center items-center gap-8 md:gap-16 mb-12 text-amber-200">
            <div className="text-center">
              <p className="text-xs uppercase tracking-widest text-amber-400 mb-2">तारीख</p>
              <p className="text-2xl font-serif">21 अप्रैल 2026</p>
            </div>
            <div className="w-px h-16 bg-gradient-to-b from-transparent via-amber-400 to-transparent hidden md:block" />
            <div className="text-center">
              <p className="text-xs uppercase tracking-widest text-amber-400 mb-2">स्थान</p>
              <p className="text-2xl font-serif">शेखपुरा, बिहार</p>
            </div>
          </div>

          {/* Elegant Wedding Avatars - HERO */}
          <div className="flex justify-center items-center gap-6 md:gap-16 mb-12">
            {/* Groom Avatar - Ajit */}
            <div className="group relative flex flex-col items-center">
              <div className="absolute inset-0 bg-gradient-to-r from-amber-400 to-rose-400 rounded-full blur-3xl opacity-60 group-hover:opacity-80 transition-opacity" />
              <div className="relative w-52 h-52 md:w-72 md:h-72 rounded-full overflow-hidden border-4 border-amber-300 shadow-2xl group-hover:scale-110 transition-transform duration-500">
                <Image
                  src="/groom.png"
                  alt="अजित - वर"
                  fill
                  className="object-cover"
                />
              </div>
              <p className="text-center text-amber-200 text-2xl font-serif font-bold mt-6">अजित</p>
              <p className="text-center text-amber-300 text-sm mt-2">पुत्र - श्री अशोक रविदास </p>
            </div>

            {/* Bride Avatar - Karuna */}
            <div className="group relative flex flex-col items-center">
              <div className="absolute inset-0 bg-gradient-to-r from-rose-400 to-amber-400 rounded-full blur-3xl opacity-60 group-hover:opacity-80 transition-opacity" />
              <div className="relative w-52 h-52 md:w-72 md:h-72 rounded-full overflow-hidden border-4 border-rose-300 shadow-2xl group-hover:scale-110 transition-transform duration-500 bg-white flex items-center justify-center">
                <Image
                  src="/bride.png"
                  alt="करूणा - दुल्हन"
                  fill
                  className="object-contain p-4"
                />
              </div>
              <p className="text-center text-rose-200 text-2xl font-serif font-bold mt-6">करूणा</p>
              <p className="text-center text-rose-300 text-sm mt-2">पुत्री - श्री शुबोध रविदास</p>
            </div>
          </div>

          {/* Scroll Indicator */}
          <div className="animate-bounce text-amber-400 text-2xl">↓</div>
        </div>
      </section>

      {/* EVENTS SECTION */}
      <section className="relative py-32 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-bold text-center mb-4 text-amber-200">मांगलिक कार्यक्रम</h2>
          <div className="h-1 w-32 bg-gradient-to-r from-amber-400 to-rose-400 mx-auto mb-16" />

          <div className="grid md:grid-cols-3 gap-8">
            {/* Haldi */}
            <div className="group relative transform hover:scale-105 transition-transform duration-300">
              <div className="absolute inset-0 bg-gradient-to-br from-amber-500/40 to-rose-500/20 rounded-2xl blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="relative bg-gradient-to-br from-amber-950/60 via-slate-900/50 to-slate-950/60 backdrop-blur-xl border-2 border-amber-400/40 group-hover:border-amber-300/80 rounded-2xl p-8 transition-all duration-300 shadow-xl group-hover:shadow-2xl group-hover:shadow-amber-500/30">
                <div className="text-5xl mb-4 group-hover:scale-125 transition-transform duration-300">🌼</div>
                <h3 className="text-3xl font-serif font-bold text-amber-200 group-hover:text-amber-100 mb-3 transition-colors">हल्दी</h3>
                <p className="text-amber-100/70 group-hover:text-amber-100 text-sm mb-4 transition-colors">"मंगलमय जीवन की शुरुआत हेतु हल्दी लेपन की दिव्य एवं पवित्र रस्म"</p>
                <div className="space-y-3 text-amber-200/80 group-hover:text-amber-200 text-sm transition-colors">
                  <p className="font-medium">📅 21 अप्रैल 2026</p>
                  <p className="font-medium">🕐 2:00 बजे दोपहर</p>
                  <p className="font-medium">📍 महादेव नगर, गिरिहिंडा</p>
                </div>
              </div>
            </div>

            {/* Mehandi */}
            <div className="group relative transform hover:scale-105 transition-transform duration-300">
              <div className="absolute inset-0 bg-gradient-to-br from-rose-500/40 to-amber-500/20 rounded-2xl blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="relative bg-gradient-to-br from-rose-950/60 via-slate-900/50 to-slate-950/60 backdrop-blur-xl border-2 border-rose-400/40 group-hover:border-rose-300/80 rounded-2xl p-8 transition-all duration-300 shadow-xl group-hover:shadow-2xl group-hover:shadow-rose-500/30">
                <div className="text-5xl mb-4 group-hover:scale-125 transition-transform duration-300">💚</div>
                <h3 className="text-3xl font-serif font-bold text-rose-200 group-hover:text-rose-100 mb-3 transition-colors">मेहंदी</h3>
                <p className="text-rose-100/70 group-hover:text-rose-100 text-sm mb-4 transition-colors">"सौंदर्य, उल्लास और शुभकामनाओं से सजी मेहंदी समारोह"</p>
                <div className="space-y-3 text-rose-200/80 group-hover:text-rose-200 text-sm transition-colors">
                  <p className="font-medium">📅 21 अप्रैल 2026</p>
                  <p className="font-medium">🕐 4:00 बजे शाम</p>
                  <p className="font-medium">📍 महादेव नगर, गिरिहिंडा</p>
                </div>
              </div>
            </div>

            {/* Sangeet */}
            <div className="group relative transform hover:scale-105 transition-transform duration-300">
              <div className="absolute inset-0 bg-gradient-to-br from-amber-500/40 to-rose-500/20 rounded-2xl blur-2xl opacity-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="relative bg-gradient-to-br from-amber-950/60 via-slate-900/50 to-slate-950/60 backdrop-blur-xl border-2 border-amber-400/40 group-hover:border-amber-300/80 rounded-2xl p-8 transition-all duration-300 shadow-xl group-hover:shadow-2xl group-hover:shadow-amber-500/30">
                <div className="text-5xl mb-4 group-hover:scale-125 transition-transform duration-300">🎵</div>
                <h3 className="text-3xl font-serif font-bold text-amber-200 group-hover:text-amber-100 mb-3 transition-colors">संगीत</h3>
                <p className="text-amber-100/70 group-hover:text-amber-100 text-sm mb-4 transition-colors">"मधुर धुनों, मनमोहक नृत्य और आनंद से भरपूर भव्य संगीत समारोह"</p>
                <div className="space-y-3 text-amber-200/80 group-hover:text-amber-200 text-sm transition-colors">
                  <p className="font-medium">📅 21 अप्रैल 2026</p>
                  <p className="font-medium">🕐 8:00 बजे रात</p>
                  <p className="font-medium">📍 महादेव नगर, गिरिहिंडा</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* WEDDING QUOTE SECTION */}
      <section className="relative py-20 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="group relative">
            <div className="absolute inset-0 bg-gradient-to-r from-amber-500/30 to-rose-500/30 rounded-3xl blur-2xl opacity-60 group-hover:opacity-80 transition-opacity" />
            <div className="relative bg-gradient-to-br from-amber-950/70 via-slate-900/60 to-rose-950/70 backdrop-blur-xl border-2 border-amber-400/50 group-hover:border-amber-300/80 rounded-3xl p-12 md:p-16 shadow-2xl group-hover:shadow-amber-500/40 transition-all">
              <div className="text-center space-y-6">
                <p className="text-amber-300 text-5xl">💍</p>
                <p className="text-amber-200 text-3xl md:text-4xl font-serif font-bold leading-relaxed">
                  🌸💖 बाबुल के आँगन की छाया थी जो, <br />
                  ✨ आज किसी और का घर सजाएगी ✨<br />
                  😊💕 अपनी हँसी और प्यार से, 💕😊<br />
                  🤝❤️ दो परिवारों को एक बनाएगी ❤️🤝
                </p>
                      <div className="h-1 w-24 bg-gradient-to-r from-amber-400 to-rose-400 mx-auto" />
                      <p className="text-amber-100/80 text-lg italic font-light">
                        “दो दिलों का प्रेम, दो परिवारों का पावन संगम,
                        और एक नए जीवन की मंगलमय शुरुआत।” 💍✨
                      </p>
                    </div>
                  </div>
              </div>
            </div>
          </section>

      {/* VENUE SECTION */}
      <section className="relative py-32 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-5xl md:text-6xl font-serif font-bold text-center mb-16 text-rose-200">कार्यक्रम स्थान</h2>

          <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-amber-400/30 rounded-2xl p-8 max-w-2xl mx-auto">
            <h3 className="text-3xl font-serif font-bold text-amber-200 mb-8 text-center">महादेव नगर, शेखपुरा</h3>
                <div className="space-y-8 text-amber-100/80">
                  <div>
                    <p className="text-xs uppercase tracking-widest text-amber-400 mb-3 font-semibold">पता</p>
                    <p className="text-lg leading-relaxed">महादेव नगर<br />गिरिहिंडा, शेखपुरा<br />बिहार 811105</p>
                  </div>
                  <div className="h-px bg-gradient-to-r from-transparent via-amber-400/30 to-transparent" />
                  <div>
                    <p className="text-xs uppercase tracking-widest text-amber-400 mb-3 font-semibold">संपर्क</p>
                    <p className="text-lg font-medium">SMS: +91 6203800342</p>
                  </div>
                  <div className="h-px bg-gradient-to-r from-transparent via-amber-400/30 to-transparent" />
                  <div>
                    <p className="text-xs uppercase tracking-widest text-amber-400 mb-3 font-semibold">तारीख एवं समय</p>
                    <p className="text-lg">21 अप्रैल 2026<br />हल्दी • मेहंदी • संगीत</p>
                  </div>
                </div>
              </div>
            </div>
      </section>

      {/* RSVP SECTION */}
      <section className="relative py-32 px-4">
        <div className="max-w-2xl mx-auto">
              <h2 className="text-5xl md:text-6xl font-serif font-bold text-center mb-8 text-amber-200">अपनी उपस्थिति दर्ज करें</h2>
              <p className="text-center text-amber-100/70 mb-12 text-lg">“जीवन के इस शुभ और पवित्र संगम पर 💍✨
                हम आपको सादर आमंत्रित करते हैं 🙏🌸।
                कृपया सपरिवार पधारकर हमें अपना आशीर्वाद दें 💐💖,
                ताकि आपके स्नेह और शुभकामनाओं से
                हमारे नए जीवन की शुरुआत और भी मंगलमय हो सके। 🌼🏡✨
                आपकी उपस्थिति हमारे लिए अनमोल उपहार होगी। 🎁💞”</p>

              {!isFormOpen ? (
                <div className="text-center">
                  <button
                    onClick={() => setIsFormOpen(true)}
                    className="px-12 py-4 bg-gradient-to-r from-amber-400 to-rose-400 hover:from-amber-300 hover:to-rose-300 text-black font-serif font-bold text-xl rounded-lg shadow-2xl hover:shadow-amber-400/50 transition-all duration-300 transform hover:scale-105"
                  >
                    🌷 आपकी स्नेहमयी उपस्थिति की हार्दिक अपेक्षा है। 💖
                  </button>
                </div>
              ) : (
                <form onSubmit={handleFormSubmit} className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-amber-400/30 rounded-2xl p-8 space-y-6">
                  <input
                    type="text"
                    placeholder="आपका नाम"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                    className="w-full bg-slate-950/50 border border-amber-400/30 rounded-lg px-4 py-3 text-white placeholder-amber-200/50 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all"
                  />

                  <select
                    value={formData.attending}
                    onChange={(e) => setFormData({ ...formData, attending: e.target.value })}
                    className="w-full bg-slate-950/50 border border-amber-400/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all"
                  >
                    <option value="yes">हाँ, मैं आऊंगा</option>
                    <option value="no">नहीं, मैं नहीं आ सकता</option>
                    <option value="maybe">शायद</option>
                  </select>

                  <textarea
                    placeholder="कोई विशेष आवश्यकता या शुभकामनाएं..."
                    value={formData.comments}
                    onChange={(e) => setFormData({ ...formData, comments: e.target.value })}
                    className="w-full bg-slate-950/50 border border-amber-400/30 rounded-lg px-4 py-3 text-white placeholder-amber-200/50 focus:outline-none focus:border-amber-400 focus:ring-2 focus:ring-amber-400/20 transition-all resize-none h-20"
                  />

                  {submitStatus === 'success' && (
                    <div className="p-4 bg-green-500/20 border border-green-400/50 rounded-lg text-green-200 text-center">
                      आपकी प्रतिक्रिया +91 6203800342 पर SMS भेजी गई है
                    </div>
                  )}

                  {submitStatus === 'error' && (
                    <div className="p-4 bg-red-500/20 border border-red-400/50 rounded-lg text-red-200 text-center">
                      फॉर्म जमा करने में त्रुटि। कृपया पुनः प्रयास करें।
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={submitStatus === 'loading'}
                    className="w-full px-6 py-3 bg-gradient-to-r from-amber-400 to-rose-400 hover:from-amber-300 hover:to-rose-300 disabled:from-gray-600 disabled:to-gray-600 text-black font-serif font-bold rounded-lg transition-all shadow-lg"
                  >
                    {submitStatus === 'loading' ? 'भेजा जा रहा है...' : 'आरएसवीपी भेजें'}
                  </button>
                </form>
              )}
            </div>
          </section>

      {/* FOOTER */}
      <footer className="relative py-16 px-4 border-t border-amber-400/20 text-center">
        <p className="text-amber-200 font-serif text-2xl mb-2">अजित एवं करूणा</p>
        <p className="text-amber-100/60">21 अप्रैल 2026 • शेखपुरा, बिहार</p>
        <p className="text-amber-100/40 text-sm mt-4">हमारे समारोह का हिस्सा बनने के लिए धन्यवाद</p>
      </footer>
    </div>
  )
}
