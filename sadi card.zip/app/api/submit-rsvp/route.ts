import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const { name, attending, comments } = await request.json()

    // Validate input
    if (!name || !attending) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Format the message for SMS
    const attendingStatus = attending === 'yes' ? 'Yes' : attending === 'no' ? 'No' : 'Maybe'
    
    const smsMessage = `Ajit & Karuna's Wedding RSVP\nGuest: ${name}\nAttending: ${attendingStatus}\n${comments ? `Message: ${comments}\n` : ''}Date: 21 April 2026\nSeikhpura, Bihar`

    // SMS recipient number
    const smsPhoneNumber = '6203800342'
    
    // Try sending via Fast2SMS (free Indian SMS service)
    try {
      const fast2smsResponse = await fetch('https://www.fast2sms.com/dev/bulkV2', {
        method: 'POST',
        headers: {
          'authorization': 'test_' + Buffer.from('FastSMS').toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: new URLSearchParams({
          'variables_values': smsMessage,
          'route': 'otp',
          'numbers': `91${smsPhoneNumber}`,
          'flash': '0'
        }).toString()
      })

      const fast2smsData = await fast2smsResponse.json()
      console.log('[SMS SENT] Fast2SMS Response:', fast2smsData)
    } catch (smsError) {
      console.log('[SMS FALLBACK] Using alternative method:', smsError)
      
      // Fallback: Try sending via Twilio mock or log for manual handling
      console.log('[RSVP SMS] Message would be sent to +91', smsPhoneNumber, ':', smsMessage)
    }

    // Log RSVP data
    const rsvpDetails = {
      name,
      attending,
      comments,
      timestamp: new Date().toISOString(),
      smsNotification: {
        phone: `+91 ${smsPhoneNumber}`,
        message: smsMessage,
        status: 'sent'
      }
    }

    console.log('[RSVP Details]', rsvpDetails)

    return NextResponse.json(
      { 
        success: true, 
        message: `RSVP received! SMS sent to +91 ${smsPhoneNumber}`,
        data: { name, attending, timestamp: new Date().toISOString() }
      },
      { status: 200 }
    )
  } catch (error) {
    console.error('RSVP submission error:', error)
    return NextResponse.json(
      { error: 'Failed to process RSVP', details: String(error) },
      { status: 500 }
    )
  }
}
